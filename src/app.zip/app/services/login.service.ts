import { Injectable } from '@angular/core';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  private isAuthenticated = false; 

  login(email: string, password: string): boolean {
    if (email === 'admin@wosh.co.il' && password === 'admin@wosh') { 
      this.isAuthenticated = true;
      return true;
    }
    
    this.isAuthenticated = true;
      return true;
  }

  logout(): void {
    this.isAuthenticated = false;
  }

  isLoggedIn(): boolean {
    return this.isAuthenticated;
  }
}
