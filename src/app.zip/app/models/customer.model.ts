export class Customer {
    id: number;
    name: string;
    email: string;
    phoneNumber: string;

    constructor(id: number, name: string,  email: string,phoneNumber:string ){
        this.id = id;
        this.name = name;
        this.email = email;
        this.phoneNumber = phoneNumber;
       
    }

  }
  