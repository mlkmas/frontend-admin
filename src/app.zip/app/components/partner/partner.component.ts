import { Component } from '@angular/core';

@Component({
  selector: 'app-partner',
  imports: [],
  templateUrl: './partner.component.html',
  styleUrl: './partner.component.css'
})
export class PartnerComponent {

}
